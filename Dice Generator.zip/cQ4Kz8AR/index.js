// javascript
let firstRoll = 1
let secondRoll = 4
let sum = firstRoll + secondRoll
let sumEl = document.getElementById("sum-el")
let diceButton = document.getElementById("dice")


diceButton.addEventListener("click", function(){
    rollOne = Math.floor(Math.random() * 6) + 1
    rollTwo = Math.floor(Math.random() * 6) + 1
    sumEl.textContent= rollOne + " " + "and " + rollTwo
    
    
})




